package pigdm.jspacefight.interfaces;

import javax.swing.ImageIcon;

public interface IImage {

    ImageIcon loadImage();

}
